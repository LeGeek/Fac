var searchData=
[
  ['head',['head',['../da/d53/class_tree_a_v_l.html#a7d77c489adc9149acc336c101086ca24',1,'TreeAVL']]]
];
